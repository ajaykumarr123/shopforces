from django.contrib import admin
from .models import leave_request

admin.site.register(leave_request)
